<section class="container-fluid" id="block_04">
    <div class="container block mt-4 d-flex flex-column align-items-center">
        <p>São 10 tópicos abrangentes, cada um repleto de conteúdos
            atualizados e estruturados em um formato passo-a-passo.</p>

        <p>Com exemplos práticos, você aprenderá de forma fácil e intuitiva,
            abrindo caminho para uma mentalidade de crescimento e sucesso.</p>
        
        <p>Prepare-se para desbloquear todo o seu potencial e revolucionar
            sua abordagem profissional.</p>
    </div>
</section>