<section class="container-fluid" id="block_05">
    <div class="container block mt-4 d-flex flex-column align-items-center">
        <h2 class="block_title text_green">Qual é o valor do seu sucesso?</h2>

        <p>Com este Ebook, você não apenas investe em conhecimento valioso, mas
            também garante um caminho para gerar renda extra nas férias. Uma
            oportunidade única de alcançar a liberdade financeira que você tanto
            almeja.</p>
            
            <p class="text_orange text-uppercase"><strong>É mais do que um livro; é o seu ingresso para transformar sua
            carreira e sua vida, por apenas:</strong></p>

            <div class="values">
                <h2><span class="text-muted">De:</span> <span class="text-decoration-line-through">R$109,90</span></h2>
                <h2>Por 3x 19,96</h2>
                <h2>Ou à vista 49,90</h2>
            </div>

    </div>
</section>