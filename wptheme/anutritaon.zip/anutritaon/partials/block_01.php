<header class="container block d-flex flex-column align-items-center" id="block_01">

    <img src="img/title.anutritaon.webp"
        class="img-fluid mb-4"
        width="800"
        height="172"
        alt="A Nutri tá On - Renda extra já">

    <p class="block_text text-center text_green mt-4"><strong>Descubra como conquistar <span class="text_orange">RENDA EXTRA</span> ainda neste verão
        2023/2024, por meio de estratégias, <span class="text_orange">inovações e insights</span>
        revolucionários para sua carreira no <span class="text_orange">mercado digital</span></strong></p>

    <img 
        src="img/capa-ebook.webp"
        class="img-fluid my-4 py-4"
        width="550"
        height="624"
        alt="Capa do E-book: Descubra estratégias mais atuais e inovadoras do mercado digital para nutricionistas">

    <a href="#" class="btn btn-lg btn-success py-3 rounded-pill btn-nutri my-4">
        Quero conquistar renda extra
    </a>
</header>