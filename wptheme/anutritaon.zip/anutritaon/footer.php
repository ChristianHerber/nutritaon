    <a href="#block_01" class="backto-top shadow rounded">
        <img 
            src="img/up-arrow.png"
            alt="Voltar ao Topo"
            width="16"
            height="16">
    </a>

</body>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</html>