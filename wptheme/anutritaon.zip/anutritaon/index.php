<?php
    get_header();
    get_template_part('partials/block_01');
    get_template_part('partials/block_02');
    get_template_part('partials/block_03');
    get_template_part('partials/block_04');
    get_template_part('partials/block_05');
    get_footer();